Juego desarrollado en Unity3D durante la Global Game Jam 2021

* Para ejecutar el juego tan solo acceder al directorio /src/ y ejecutar el archivo "Git Gat Gud.exe"

CONTROLES
Mouse -> Navegación por los menús
Flechas de dirección / W,A,S,D -> Movimiento


----------

Game developed in Unity3D for Global Game Jam 2021

* To run the game just access to the /src/ directory and run the "Git Gat Gud.exe" file

CONTROLS
Mouse -> Menu navigation
Arrow keys / W,A,S,D -> Movement